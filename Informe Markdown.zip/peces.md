---
title: "Informe Académico: Guía de Modelado y Simulación Dinámica de Recursos Pesqueros"
author: "Luna Juan Agustin, Cardenas Juan, Noriega Lucina, Olguin Leandro, Galli Ariana"
output:
  html_document:
    toc: true
    toc_depth: 3
    toc_float: true
    theme: cosmo
    highlight: tango
    number_sections: true
  pdf_document:
    toc: true
    number_sections: true
  word_document:
    toc: true
    toc_depth: '3'
---

# Introducción y Marco Teórico de Dinámica de Sistemas

El estudio del colapso de los recursos naturales renovables constituye uno de los desafíos más críticos en la gestión ambiental y la economía del desarrollo. El presente informe establece una guía para la construcción, acoplamiento y experimentación de un modelo dinámico de simulación enfocado en la explotación pesquera, fundamentado en la metodología de Dinámica de Sistemas desarrollada por Dennis Meadows y adaptada en la literatura técnica de *Fish Banks*.

La Dinámica de Sistemas permite representar la estructura interna de sistemas complejos mediante variables de acumulación (niveles o *stocks*), flujos de entrada y salida, y bucles de retroalimentación acoplados. En los sistemas pesqueros reales, la interacción entre la biología poblacional de los peces y la lógica económica de inversión de la flota pesquera genera dinámicas no lineales complejas, caracterizadas por retrasos temporales y colapsos repentinos del recurso.

------------------------------------------------------------------------

# Subsistema Biológico de la Población de Peces

## Descripción Estructural y Supuestos Biológicos

El subsistema biológico representa la dinámica poblacional de los peces en ausencia de intervención humana o industria pesquera. El sistema se modela como un proceso de crecimiento logístico en forma de S (*S-shaped growth*). En condiciones naturales, la población de peces crece a través de nacimientos y se reduce mediante mortalidad natural, alcanzando un equilibrio dinámico sustentable determinado por la capacidad de carga del ecosistema (*Carrying Capacity*).

Si la población se reduce por perturbaciones externas, la biología del sistema reacciona acelerando el crecimiento neto hasta retornar al equilibrio dinámico de la capacidad de carga.

## Formulación Matemática y Variables del Subsistema

La estructura del subsistema biológico se define matemáticamente mediante una ecuación diferencial donde la variable de nivel principal es el stock de peces $FISH(t)$:

$$\frac{d(FISH)}{dt} = \text{Fish_Hatch_Rate}(t) - \text{Fish_Death_Rate}(t)$$

En forma discreta para su implementación computacional con un paso de integración $DT$, la ecuación adopta la siguiente forma:

$$FISH(t) = FISH(t - dt) + (\text{Fish_Hatch_Rate} - \text{Fish_Death_Rate}) \times dt$$

A continuación se detallan las ecuaciones auxiliares, flujos y parámetros que gobiernan el subsistema biológico:

1.  **Stock Inicial de Peces (**$FISH_{0}$): Para la simulación del crecimiento biológico aislado, se establece una población inicial reducida de 10 peces ($FISH_{0} = 10$). En la simulación acoplada completa, la condición inicial se fija en 1000 peces.
2.  **Capacidad de Carga (**$Carrying\_Capacity$): Parámetro constante fijado en 1200 peces, el cual representa el límite máximo ecológico que el entorno puede sostener de forma sustentable.
3.  **Tasa de Nacimientos (**$\text{Fish_Hatch_Rate}$): Flujo de entrada proporcional al tamaño de la población viva:

$$\text{Fish_Hatch_Rate} = FISH \times Hatch\_Fraction$$

donde la fracción de nacimiento $Hatch\_Fraction = 6\text{ años}^{-1}$. Este valor surge de asumir que el $50\%$ de la población son hembras y que cada hembra produce un promedio de 12 alevines viables por año.

4.  **Tasa de Mortalidad Natural (**$\text{Fish_Death_Rate}$): Flujo de salida no lineal afectado por el nivel de hacinamiento de la población:

$$\text{Fish_Death_Rate} = FISH \times Death\_Fraction$$

5.  **Fracción de Mortalidad (**$Death\_Fraction$): Función no lineal dependiente de la relación de hacinamiento entre la población actual y la capacidad de carga del entorno ($FISH / Carrying\_Capacity$):

$$Death\_Fraction = f\left(\frac{FISH}{Carrying\_Capacity}\right)$$

| Ratio de Hacinamiento ($\frac{FISH}{Carrying\_Capacity}$) | Fracción de Mortalidad ($Death\_Fraction$, año$^{-1}$) |
|:----------------------------------:|:----------------------------------:|
| $0.00$ | $5.22$ |
| $0.10$ | $5.22$ |
| $0.20$ | $5.23$ |
| $0.30$ | $5.24$ |
| $0.40$ | $5.26$ |
| $0.50$ | $5.29$ |
| $0.60$ | $5.34$ |
| $0.70$ | $5.45$ |
| $0.80$ | $5.66$ |
| $0.90$ | $5.94$ |
| $1.00$ | $6.00$ |

![](Mortalidad.png)

## Bucles de Retroalimentación y Comportamiento Aislado

El subsistema de peces está gobernado por dos bucles de retroalimentación principales:

- **Bucle de Retroalimentación Positiva (+):** A mayor número de peces ($FISH$), mayor es la tasa de nacimientos ($\text{Fish_Hatch_Rate}$), lo que a su vez incrementa la población. Este bucle domina durante las fases iniciales cuando la densidad es baja.

- **Bucle de Retroalimentación Negativa (-):** A medida que la población $FISH$ se aproxima a los 1200 peces, el hacinamiento incrementa la $Death\_Fraction$ hasta equipararla con la $Hatch\_Fraction$ (ambas en $6.0$ al alcanzar la capacidad de carga), estabilizando la población en un equilibrio dinámico.

  ## Diagrama Simulado

  ![](Peces.png)

------------------------------------------------------------------------

# Subsistema Económico de la Flota Pesquera

## Descripción Estructural y Supuestos Económicos

El subsistema económico modela el comportamiento agregativo de las empresas pesqueras. Para mantener la coherencia analítica y reducir la complejidad sin perder validez sistémica, el modelo consolida a todas las compañías pesqueras individuales en una única flota agregada representada por el stock de barcos $SHIPS(t)$.

La fuerza impulsora de la inversión pesquera es la rentabilidad anual de la flota. Las empresas reinvierten una fracción fija de sus ganancias anuales positivas en la adquisición y construcción de nuevas embarcaciones.

## Formulación Matemática y Ecuaciones Financieras

La evolución del número de barcos se define mediante la siguiente ecuación acumulativa:

$$SHIPS(t) = SHIPS(t - dt) + (\text{Ship_Building_Rate}) \times dt$$

donde las variables y parámetros del módulo económico se estructuran como sigue:

1.  **Flota Inicial (**$SHIPS_{0}$): La condición inicial de la flota pesquera se fija en 10 barcos.
2.  **Tasa de Construcción de Barcos (**$\text{Ship_Building_Rate}$): Flujo de entrada condicionado a la existencia de beneficios económicos positivos:

$$\text{Ship_Building_Rate} = \max\left(0, \frac{\text{Yearly_Profits} \times Fraction\_Invested}{Ship\_Cost}\right)$$

3.  **Fracción de Ganancias Reinvertida (**$Fraction\_Invested$): Constante fijada en $0.20$ ($20\%$ de las ganancias anuales se destinan a la compra de barcos).
4.  **Costo de Construcción por Barco (**$Ship\_Cost$): Precio de adquisición fijado inicialmente en $\$300$ por barco.
5.  **Ingresos Anuales (**$Revenues$): Calculados como el producto de la captura total de la industria por el precio de mercado del pescado:

$$Revenues = \text{Total_Catch_per_Year} \times Fish\_Price$$

donde $Fish\_Price = \$20$ por pez.

6.  **Costos Operativos Anuales (**$Costs$): Calculados a partir de los costos operativos por embarcación en servicio:

$$Costs = SHIPS \times Operating\_Costs\_per\_Ship$$

donde $Operating\_Costs\_per\_Ship = \$250$ por barco al año.

7.  **Ganancias Anuales (**$\text{Yearly_Profits}$):

$$\text{Yearly_Profits} = Revenues - Costs$$

## El Bucle de Reinversión Financiera

En el subsistema aislado de barcos (asumiendo temporalmente una captura constante por barco de $15\text{ peces/barco/año}$), el sistema presenta un bucle de retroalimentación positiva de crecimiento exponencial: más barcos generan mayor captura total, lo que eleva los ingresos, incrementa las ganancias anuales e impulsa una mayor tasa de construcción de embarcaciones.

## Diagrama Simulado

![](Barcos.png)

------------------------------------------------------------------------

# Subsistema Acoplado Completo: Interacción Peces-Barcos

## La Conexión Densidad-Captura y la Dinámica de Captura

El acoplamiento del subsistema biológico y el económico constituye el núcleo del modelo dinámico de recursos pesqueros. En el modelo completo, la captura por barco ya no es constante, sino que depende directamente de la densidad poblacional de los peces en la zona de pesca.

$$\text{Total_Catch_per_Year} = SHIPS \times \text{Catch_per_Ship}$$

Las ecuaciones de acoplamiento espacial y tecnológico son las siguientes:

1.  **Área Pesquera (**$Area$): Constante espacial fijada en $100\text{ millas cuadradas}$.
2.  **Densidad de Peces (**$Density$):

$$Density = \frac{FISH}{Area}$$

3.  **Captura por Barco (**$\text{Catch_per_Ship}$): Función no lineal tipo tabla o gráfico (*lookup*) dependiente de la densidad de peces:

$$\text{Catch_per_Ship} = f(Density)$$

| Densidad de Peces ($Density$, $\text{peces/milla}^2$) | Captura por Barco ($\text{Catch_per_Ship}$, $\text{peces/barco . año}$) |
|:-----------------------------:|:---------------------------------------:|
| $0.00$ | $0.00$ |
| $1.00$ | $5.00$ |
| $2.00$ | $10.40$ |
| $3.00$ | $15.90$ |
| $4.00$ | $20.20$ |
| $5.00$ | $22.10$ |
| $6.00$ | $23.20$ |
| $7.00$ | $23.80$ |
| $8.00$ | $24.20$ |
| $9.00$ | $24.60$ |
| $10.00$ | $25.00$ |

![](Captura.png)

## Balances de Retroalimentación y Tragedia de los Comunes

Al integrar ambos subsistemas, la captura total anual ($\text{Total_Catch_per_Year}$) se convierte en un flujo de salida directo del stock de peces $FISH(t)$:

$$FISH(t) = FISH(t - dt) + (\text{Fish_Hatch_Rate} - \text{Fish_Death_Rate} - \text{Total_Catch_per_Year}) \times dt$$

La interacción entre la biología y la economía genera la clásica **"Tragedia de los Comunes"** explicada por los siguientes bucles acoplados:

1.  **Bucle Autorregulador Negativo de la Captura (*Balancing Loop*):** Un incremento en la captura total reduce el stock $FISH$, disminuyendo la densidad poblacional. Esto reduce la captura por barco ($\text{Catch_per_Ship}$) y amortigua la captura total.
2.  **Bucle de Reinversión Pesquera y Retardo Temporal (*Overarching Reinforcing Loop*):** Las ganancias iniciales elevadas impulsan la compra continua de barcos. Debido a que la flota continúa creciendo aun cuando la densidad de peces comienza a declinar, se produce un sobreesfuerzo pesquero masivo. La captura por barco cae bruscamente, los costos operativos superan a los ingresos y el stock de peces se desploma drásticamente hacia el colapso.

------------------------------------------------------------------------

# Protocolo de Construcción e Simulación Computacional

Para implementar la simulación en paquetes de software de Dinámica de Sistemas (Vensim), se debe seguir el protocolo metodológico descrito a continuación.

## Configuración de Parámetros de Integración Computacional

- **Paso de Integración (**$dt$): $dt = 0.1\text{ años}$ (ó $0.05\text{ años}$ para integración numérica Euler o Runge-Kutta de 4to orden).
- **Tiempo Inicial (**$INITIAL\_TIME$): $0\text{ años}$.
- **Tiempo Final (**$FINAL\_TIME$): $12\text{ a }15\text{ años}$ para análisis de colapso base; $50\text{ a }100\text{ años}$ para análisis de sustentabilidad de largo plazo.

## Pasos de Ensamblaje Modular en Software de Simulación

1.  **Paso 1: Construcción del Módulo de Población de Peces:**
    - Crear el stock $FISH$ con valor inicial de $10$.
    - Definir los flujos `Fish_Hatch_Rate` y `Fish_Death_Rate`.
    - Conectar los conversores `Hatch_Fraction` ($6.0$), `Carrying_Capacity` ($1200$) y la tabla no lineal `Death_Fraction`.
    - Verificar la curva de crecimiento logístico en S alcanzando los $1200$ peces en el año 12.
2.  **Paso 2: Construcción del Módulo Económico de Barcos:**
    - Crear el stock $SHIPS$ con valor inicial de $10$.
    - Definir el flujo `Ship_Building_Rate` con la función condicional $\max(0, \dots)$.
    - Introducir las constantes $Ship\_Cost = \$300$, $Fraction\_Invested = 0.20$, $Operating\_Costs\_per\_Ship = \$250$ y $Fish\_Price = \$20$.
3.  **Paso 3: Acoplamiento e Interconexión Final:**
    - Cambiar el stock inicial de peces a $FISH(0) = 1000$.
    - Conectar `Total_Catch_per_Year` como flujo de salida del stock $FISH$.
    - Definir la variable $Density = FISH / Area$ ($Area = 100$) y la tabla no lineal `Catch_per_Ship`.
    - Ejecutar el modelo sin regulación y observar el colapso del ecosistema pesquero.

## Diagrama Final

![](D-Final.png)

# Formulación de Políticas Públicas de Regulación Pesquera

Dado que el modelo en su estado base conduce inevitablemente a la destrucción del recurso pesquero y a la quiebra de la industria, las autoridades regulatorias deben evaluar políticas de regulación estructural.

## Política 1: Impuesto Directo a la Construcción de Embarcaciones

- **Mecanismo de Modificación:** Desincentivar la acumulación de capital imponiendo un impuesto sustancial sobre la compra de nuevos barcos (por ejemplo, un impuesto de $\$200$ por barco), lo que incrementa el parámetro $Ship\_Cost$ de $\$300$ a $\$500$ por barco.
- **Objetivo Técnico:** Reducir el flujo $\text{Ship_Building_Rate}$ dividiendo la inversión disponible entre un costo unitario mayor, ralentizando la expansión de la flota.

## Política 2: Regulación de la Eficiencia Tecnológica de Pesca

- **Mecanismo de Modificación:** Declarar ilegales ciertas tecnologías de pesca de alta eficiencia (como redes de arrastre de gran escala o ecosondas avanzadas), alterando la curva tipo tabla de $\text{Catch_per_Ship}$.
- **Objetivo Técnico:** Desplazar la función $Catch\_per\_Ship = f(Density)$ hacia abajo para todos los niveles de densidad, reduciendo la efectividad extractiva unitaria y protegiendo la biomasa de peces.

## Política 3: Retiro Obligatorio y Desguace de Barcos por Antigüedad

- **Mecanismo de Modificación:** Establecer regulaciones de seguridad que obliguen al retiro de circulación (*desguace* o *dry-docking*) de las embarcaciones tras superar un período límite de vida útil.
- **Objetivo Técnico:** Introducir un flujo de salida explícito del stock de barcos ($\text{Ship_Decommissioning_Rate} = SHIPS / \text{Average_Ship_Life}$), rompiendo la acumulación indefinida de la flota.

## Política 4: Control de Precios y Aranceles sobre la Captura

- **Mecanismo de Modificación:** Fijar precios máximos gubernamentales al pescado ($Fish\_Price$) o aplicar impuestos por tonelada desembarcada.
- **Objetivo Técnico:** Limitar los ingresos anuales ($Revenues$) de las empresas pesqueras, suprimiendo las ganancias extraordinarias que financian el sobreesfuerzo pesquero.

## Política 5: Veda Pesquera y Cuotas Globales de Captura

- **Mecanismo de Modificación:** Condicionar el esfuerzo pesquero o pausar las licencias de construcción cuando el indicador de densidad o captura por barco caiga por debajo de un umbral biológico de seguridad.
- **Objetivo Técnico:** Prevenir la depleción extrema estableciendo mecanismos de control en la tasa de construcción de embarcaciones.
